/*
 * AddressBook.cpp
 *
 *  Created on: Sep 17, 2020
 *      Author: vessa
 */

#include "AddressBook.hpp"

AddressBook::AddressBook()
{
	if (DEBUG)
		std::cout << "<<< Entering AddressBook::DefaultConstructor >>>" << std::endl;

	head = nullptr;
	tail = nullptr;
	numItemsInList = 0;
}

AddressBook::~AddressBook()
{
	if (DEBUG)
		std::cout << "<<< Entering AddressBook::Destructor >>>" << std::endl;

	delete head;
	delete tail;
}

bool AddressBook::isEmpty() const
{
	if (DEBUG)
		std::cout << "<<< Entering isEmpty >>>" << std::endl;

	if (head == nullptr)
	{
		return true;
	}

	return false;
}

bool AddressBook::isFull() const
{
	if (DEBUG)
		std::cout << "<<< Entering isFull >>>" << std::endl;

	if (this->numItemsInList >= this->maxListSize())
	{
		return true;
	}

	return false;
}

int AddressBook::listSize() const
{
	if (DEBUG)
		std::cout << "<<< Entering listSize >>>" << std::endl;

	return this->numItemsInList;
}

int AddressBook::maxListSize() const
{
	if (DEBUG)
		std::cout << "<<< Entering maxListSize >>>" << std::endl;

	return MAXLISTSIZE;
}

void AddressBook::print() const
{
	if (DEBUG)
		std::cout << "<<< Entering print >>>" << std::endl;

	if (this->isEmpty())
	{
		std::cerr << "List is empty, item to remove is out of range." << std::endl;
		return;
	}

	AddressEntry* T = head;

	while (T != nullptr)
	{
		if (DEBUG)
			std::cout << 0 << std::endl;
		std::cout << "Name          " << T->getName() << std::endl;
		std::cout << "Address       " << T->getAddress() << std::endl;
		std::cout << "Phone Number  " << T->getPhoneNumber() << std::endl;
		T = T->next;
	}
}

void AddressBook::seqSearch(std::string fullName)
{
	if (DEBUG)
		std::cout << "<<< Entering seqSearch >>>" << std::endl;

	if (this->isEmpty())
	{
		std::cerr << "List is empty, item to remove is out of range." << std::endl;
		return;
	}

	AddressEntry* T = head;

	// Get the last object in list.
	while (head != nullptr)
	{
		// If name is found in list
		if (T->getName() == fullName)
		{
			std::cout << "Name      : " << T->getName() << std::endl;
			std::cout << "Address   : " << T->getAddress() << std::endl;
			std::cout << "Number    : " << T->getPhoneNumber() << std::endl;
			return;
		}
		T = T->next;
	}

	return;
}

void AddressBook::insertEnd(AddressEntry* newEntry)
{
	if (DEBUG)
		std::cout << "<<< Entering insertEnd >>>" << std::endl;

	//Full list case
	if (isFull())
	{
		std::cerr << "Cannot insert in a full list." << std::endl;
		return;
	}

	// Empty list case
	if (this->head == nullptr)
	{
		if (DEBUG)
			std::cout << "<<< Entering insertEnd: Checking if list is empty >>>" << std::endl;
		if (DEBUG)
			std::cout << "<<< Entering insertEnd: Inserting to list... >>>" << std::endl;

		newEntry->prev = nullptr;
		newEntry->next = nullptr;
		head = newEntry;
		tail = newEntry;
		numItemsInList++;
		return;
	}

	//Everything else.
	if (DEBUG)
		std::cout << "<<< Entering insertEnd: Inserting to list... >>>" << std::endl;

	newEntry->prev = tail;
	newEntry->next = nullptr;
	tail->next = newEntry;
	tail = newEntry;
	numItemsInList++;
}

void AddressBook::removeAt(int n)
{
	//if (DEBUG)
	std::cout << "<<< Entering removeAt >>>" << std::endl;

	//Empty case.
	if (isEmpty())
	{
		std::cerr << "List is empty, item to remove is out of range." << std::endl;
		return;
	}

	//Out of range case.
	if (n >= this->numItemsInList || n < 0)
	{
		std::cerr << "index is out of range." << std::endl;
		return;
	}

	AddressEntry* T = head;

	//If target is the head node (first node).
	if (n==0)
	{
		head = T->next;
		delete T;
		return;
	}

	//If target is the tail node (last node).
	if (n==numItemsInList)
	{
		T = tail;
		tail = tail->prev;
		delete T;
		return;
	}

	//Find target index.
	for (int i=0; i<n-1; i++)
	{
		T = T->next;
	}
	if (T->prev)
		T->prev->next = T->next;
	if (T->next)
		T->next->prev = T->prev;

	std::cout << "Deleting " << T->getName() << std::endl;

	delete T;
}

AddressEntry* AddressBook::retrieveAt(int index)
{
	if (DEBUG)
			std::cout << "<<< Entering retrieveAt >>>" << std::endl;

	//Empty case.
	if (isEmpty())
	{
		std::cerr << "List is empty, no item to return." << std::endl;
		return nullptr;
	}

	//Out of range case.
	if (index >= this->numItemsInList || index < 1)
	{
		std::cerr << "index is out of range." << std::endl;
		return nullptr;
	}

	AddressEntry* T = head;

	//Find target index.
	for (int i=1; i<index; i++)
	{
		T = T->next;
	}

	return T;
}

void AddressBook::clearList()
{
	if (DEBUG)
		std::cout << "<<< Entering clearList >>>" << std::endl;

	if (this->isEmpty())
	{
		std::cerr << "List is empty, item to remove is out of range." << std::endl;
		return;
	}

	AddressEntry* T = head;

	while (head != nullptr)
	{
		if (DEBUG)
			std::cout << 0 << std::endl;
		T = head;
		head = head->next;
		delete T;
	}
}























